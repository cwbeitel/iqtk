A toolkit. For *bioinformatics*. Oh yeah.


